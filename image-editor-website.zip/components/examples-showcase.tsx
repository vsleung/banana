import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function ExamplesShowcase() {
  const examples = [
    {
      image: "/mountain-landscape-with-dramatic-sky.jpg",
      title: "Ultra-Fast Mountain Generation",
      description: "Created in 0.8 seconds with Nano Banana's optimized neural engine",
      badge: "Nano Banana Speed",
    },
    {
      image: "/beautiful-garden-with-flowers-and-butterflies.jpg",
      title: "Instant Garden Creation",
      description: "Complex scene rendered in milliseconds using Nano Banana technology",
      badge: "Nano Banana Speed",
    },
    {
      image: "/tropical-beach-with-crystal-clear-water.jpg",
      title: "Real-time Beach Synthesis",
      description: "Nano Banana delivers photorealistic results at lightning speed",
      badge: "Nano Banana Speed",
    },
    {
      image: "/northern-lights-aurora-borealis-night-sky.jpg",
      title: "Rapid Aurora Generation",
      description: "Advanced effects processed instantly with Nano Banana AI",
      badge: "Nano Banana Speed",
    },
  ]

  return (
    <div className="container mx-auto px-4">
      <div className="text-center mb-12">
        <h3 className="text-3xl md:text-5xl font-bold text-foreground mb-4 text-balance">
          Lightning-Fast AI Creations
        </h3>
        <p className="text-lg text-muted-foreground text-pretty">See what Nano Banana generates in milliseconds</p>
      </div>
      <div className="grid md:grid-cols-2 gap-6 mb-12">
        {examples.map((example, index) => (
          <Card key={index} className="overflow-hidden bg-card border-border hover:shadow-xl transition-shadow">
            <div className="aspect-video relative overflow-hidden bg-muted">
              <img
                src={example.image || "/placeholder.svg"}
                alt={example.title}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="p-6">
              <Badge className="mb-3 bg-accent/20 text-accent-foreground border-accent/30">{example.badge}</Badge>
              <h4 className="text-xl font-semibold text-foreground mb-2 text-balance">{example.title}</h4>
              <p className="text-muted-foreground text-pretty">{example.description}</p>
            </div>
          </Card>
        ))}
      </div>
      <div className="text-center">
        <p className="text-muted-foreground mb-4">Experience the power of Nano Banana yourself</p>
        <a href="#" className="text-accent hover:underline font-medium">
          Try Nano Banana Generator →
        </a>
      </div>
    </div>
  )
}
