"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Upload, X, Wand2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"

interface ImageUploadProps {
  onImageUpload: (imageUrl: string) => void
}

export default function ImageUpload({ onImageUpload }: ImageUploadProps) {
  const [uploadedImage, setUploadedImage] = useState<string | null>(null)
  const [prompt, setPrompt] = useState("")
  const [isDragging, setIsDragging] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        const imageUrl = e.target?.result as string
        setUploadedImage(imageUrl)
        onImageUpload(imageUrl)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = () => {
    setIsDragging(false)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
    const file = e.dataTransfer.files?.[0]
    if (file && file.type.startsWith("image/")) {
      const reader = new FileReader()
      reader.onload = (e) => {
        const imageUrl = e.target?.result as string
        setUploadedImage(imageUrl)
        onImageUpload(imageUrl)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleRemoveImage = () => {
    setUploadedImage(null)
    setPrompt("")
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const handleGenerate = () => {
    console.log("[v0] Generate clicked with prompt:", prompt)
    // This is where AI generation would be implemented
  }

  return (
    <Card className="p-6 max-w-4xl mx-auto bg-card border-border">
      <div className="space-y-6">
        <div className="text-center mb-6">
          <h3 className="text-2xl font-bold text-foreground mb-2">Try The AI Editor</h3>
          <p className="text-muted-foreground">Experience the power of natural language image editing</p>
        </div>

        {/* Upload Area */}
        <div
          className={`relative border-2 border-dashed rounded-lg transition-colors ${
            isDragging ? "border-accent bg-accent/10" : "border-border hover:border-accent/50"
          }`}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          {!uploadedImage ? (
            <div className="p-12 text-center">
              <Upload className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-foreground font-medium mb-2">Drop your image here or click to upload</p>
              <p className="text-sm text-muted-foreground mb-4">Support for JPG, PNG, WebP (Max 10MB)</p>
              <Button onClick={() => fileInputRef.current?.click()} variant="outline">
                Select Image
              </Button>
              <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileChange} className="hidden" />
            </div>
          ) : (
            <div className="relative">
              <img src={uploadedImage || "/placeholder.svg"} alt="Uploaded" className="w-full h-auto rounded-lg" />
              <Button onClick={handleRemoveImage} size="icon" variant="destructive" className="absolute top-2 right-2">
                <X className="w-4 h-4" />
              </Button>
            </div>
          )}
        </div>

        {/* Prompt Input */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-foreground">Describe your desired edits</label>
          <Textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="e.g., Place the character in a snowy mountain landscape, enhance facial features, change background to sunset beach..."
            className="min-h-24 bg-background border-border text-foreground placeholder:text-muted-foreground"
          />
        </div>

        {/* Generate Button */}
        <Button
          onClick={handleGenerate}
          disabled={!uploadedImage || !prompt}
          className="w-full bg-accent text-accent-foreground hover:bg-accent/90"
          size="lg"
        >
          <Wand2 className="w-5 h-5 mr-2" />
          Generate AI Edit
        </Button>

        {uploadedImage && !prompt && (
          <p className="text-sm text-muted-foreground text-center">Enter a prompt to start editing your image</p>
        )}
      </div>
    </Card>
  )
}
