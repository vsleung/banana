import { Card } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"

export default function UserReviews() {
  const reviews = [
    {
      name: "Sarah Chen",
      role: "Digital Creator",
      avatar: "SC",
      review:
        "This editor completely changed my workflow. The character consistency is incredible - miles ahead of competitors!",
    },
    {
      name: "Marcus Rodriguez",
      role: "UGC Specialist",
      avatar: "MR",
      review:
        "Creating consistent AI influencers has never been easier. It maintains perfect face details across edits!",
    },
    {
      name: "Emily Watson",
      role: "Professional Editor",
      avatar: "EW",
      review: "One-shot editing is basically solved with this tool. The scene blending is so natural and realistic!",
    },
  ]

  return (
    <div>
      <div className="text-center mb-12">
        <h3 className="text-3xl md:text-5xl font-bold text-foreground mb-4 text-balance">What Creators Are Saying</h3>
        <p className="text-lg text-muted-foreground text-pretty">Trusted by professionals worldwide</p>
      </div>
      <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
        {reviews.map((review, index) => (
          <Card key={index} className="p-6 bg-card border-border hover:shadow-lg transition-shadow">
            <div className="flex items-center gap-3 mb-4">
              <Avatar className="w-12 h-12 bg-accent text-accent-foreground">
                <AvatarFallback>{review.avatar}</AvatarFallback>
              </Avatar>
              <div>
                <p className="font-semibold text-foreground">{review.name}</p>
                <p className="text-sm text-muted-foreground">{review.role}</p>
              </div>
            </div>
            <p className="text-muted-foreground text-pretty">"{review.review}"</p>
          </Card>
        ))}
      </div>
    </div>
  )
}
