"use client"

import { useState } from "react"
import { Upload, Sparkles, Zap, Users, ImageIcon, Layers } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import ImageUpload from "@/components/image-upload"
import ExamplesShowcase from "@/components/examples-showcase"
import UserReviews from "@/components/user-reviews"

export default function Home() {
  const [uploadedImage, setUploadedImage] = useState<string | null>(null)

  const handleImageUpload = (imageUrl: string) => {
    setUploadedImage(imageUrl)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="text-2xl">🍌</div>
            <h1 className="text-xl font-bold text-foreground">Nano Banana</h1>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <a href="#features" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Features
            </a>
            <a href="#showcase" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Examples
            </a>
            <a href="#reviews" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Reviews
            </a>
            <a href="#faq" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              FAQ
            </a>
          </nav>
          <Button className="bg-accent text-accent-foreground hover:bg-accent/90">Try Now</Button>
        </div>
      </header>

      {/* Decorative Bananas */}
      <div className="absolute top-20 left-10 text-6xl opacity-20 pointer-events-none">🍌</div>
      <div className="absolute top-40 right-20 text-4xl opacity-15 pointer-events-none rotate-45">🍌</div>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20 md:py-32 text-center relative">
        <div className="absolute top-0 right-1/4 text-5xl opacity-10 pointer-events-none">🍌</div>
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/20 text-accent-foreground mb-6">
          <Sparkles className="w-4 h-4" />
          <span className="text-sm font-medium">The AI model that outperforms competitors</span>
        </div>
        <h2 className="text-5xl md:text-7xl font-bold text-foreground mb-6 text-balance">Transform Images with AI</h2>
        <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto text-pretty">
          Experience the power of natural language image editing. Nano Banana delivers consistent character editing and
          scene preservation that surpasses industry standards.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
          <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90">
            <Upload className="w-5 h-5 mr-2" />
            Start Editing
          </Button>
          <Button size="lg" variant="outline">
            View Examples
          </Button>
        </div>
        <div className="flex items-center justify-center gap-8 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-accent" />
            <span>One-shot editing</span>
          </div>
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-accent" />
            <span>Multi-image support</span>
          </div>
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-accent" />
            <span>Natural language</span>
          </div>
        </div>
      </section>

      {/* Image Upload Section */}
      <section className="container mx-auto px-4 py-16 relative">
        <div className="absolute bottom-10 left-5 text-3xl opacity-10 pointer-events-none -rotate-12">🍌</div>
        <ImageUpload onImageUpload={handleImageUpload} />
      </section>

      {/* Features Section */}
      <section id="features" className="container mx-auto px-4 py-20 relative">
        <div className="absolute top-20 right-10 text-7xl opacity-10 pointer-events-none">🍌</div>
        <div className="text-center mb-16">
          <h3 className="text-3xl md:text-5xl font-bold text-foreground mb-4 text-balance">Core Features</h3>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
            Why choose Nano Banana? The most advanced AI image editor with natural language understanding
          </p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card className="p-6 bg-card border-border hover:shadow-lg transition-shadow">
            <div className="w-12 h-12 rounded-lg bg-accent/20 flex items-center justify-center mb-4">
              <Sparkles className="w-6 h-6 text-accent" />
            </div>
            <h4 className="text-xl font-semibold text-foreground mb-2">Natural Language Editing</h4>
            <p className="text-muted-foreground text-pretty">
              Edit images using simple text prompts. Nano Banana AI understands complex instructions like GPT for images
            </p>
          </Card>
          <Card className="p-6 bg-card border-border hover:shadow-lg transition-shadow">
            <div className="w-12 h-12 rounded-lg bg-accent/20 flex items-center justify-center mb-4">
              <Users className="w-6 h-6 text-accent" />
            </div>
            <h4 className="text-xl font-semibold text-foreground mb-2">Character Consistency</h4>
            <p className="text-muted-foreground text-pretty">
              Maintain perfect character details across edits. This model excels at preserving faces and identities
            </p>
          </Card>
          <Card className="p-6 bg-card border-border hover:shadow-lg transition-shadow">
            <div className="w-12 h-12 rounded-lg bg-accent/20 flex items-center justify-center mb-4">
              <ImageIcon className="w-6 h-6 text-accent" />
            </div>
            <h4 className="text-xl font-semibold text-foreground mb-2">Scene Preservation</h4>
            <p className="text-muted-foreground text-pretty">
              Seamlessly blend edits with original backgrounds. Superior scene fusion compared to competitors
            </p>
          </Card>
          <Card className="p-6 bg-card border-border hover:shadow-lg transition-shadow">
            <div className="w-12 h-12 rounded-lg bg-accent/20 flex items-center justify-center mb-4">
              <Zap className="w-6 h-6 text-accent" />
            </div>
            <h4 className="text-xl font-semibold text-foreground mb-2">One-Shot Editing</h4>
            <p className="text-muted-foreground text-pretty">
              Perfect results in a single attempt. Nano Banana solves one-shot image editing challenges effortlessly
            </p>
          </Card>
          <Card className="p-6 bg-card border-border hover:shadow-lg transition-shadow">
            <div className="w-12 h-12 rounded-lg bg-accent/20 flex items-center justify-center mb-4">
              <Layers className="w-6 h-6 text-accent" />
            </div>
            <h4 className="text-xl font-semibold text-foreground mb-2">Multi-Image Context</h4>
            <p className="text-muted-foreground text-pretty">
              Process multiple images simultaneously. Support for advanced multi-image editing workflows
            </p>
          </Card>
          <Card className="p-6 bg-card border-border hover:shadow-lg transition-shadow">
            <div className="w-12 h-12 rounded-lg bg-accent/20 flex items-center justify-center mb-4">
              <Sparkles className="w-6 h-6 text-accent" />
            </div>
            <h4 className="text-xl font-semibold text-foreground mb-2">AI Content Creation</h4>
            <p className="text-muted-foreground text-pretty">
              Create consistent AI influencers and UGC content. Perfect for social media and marketing campaigns
            </p>
          </Card>
        </div>
      </section>

      {/* Examples Showcase */}
      <section id="showcase" className="py-20 bg-muted/30 relative">
        <div className="absolute top-1/2 left-5 text-5xl opacity-10 pointer-events-none rotate-12">🍌</div>
        <ExamplesShowcase />
      </section>

      {/* User Reviews */}
      <section id="reviews" className="container mx-auto px-4 py-20 relative">
        <div className="absolute bottom-20 right-10 text-6xl opacity-10 pointer-events-none -rotate-12">🍌</div>
        <UserReviews />
      </section>

      {/* FAQ Section */}
      <section id="faq" className="container mx-auto px-4 py-20 relative">
        <div className="absolute top-10 left-1/4 text-4xl opacity-10 pointer-events-none">🍌</div>
        <div className="max-w-3xl mx-auto">
          <h3 className="text-3xl md:text-5xl font-bold text-foreground mb-4 text-center text-balance">
            Frequently Asked Questions
          </h3>
          <p className="text-lg text-muted-foreground mb-12 text-center text-pretty">
            Everything you need to know about Nano Banana
          </p>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-1">
              <AccordionTrigger className="text-left">What is Nano Banana?</AccordionTrigger>
              <AccordionContent className="text-muted-foreground">
                It's a revolutionary AI image editing model that transforms photos using natural language prompts. This
                is currently the most powerful image editing model available, with exceptional consistency. It offers
                superior performance for consistent character editing and scene preservation.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-2">
              <AccordionTrigger className="text-left">How does it work?</AccordionTrigger>
              <AccordionContent className="text-muted-foreground">
                Simply upload an image and describe your desired edits in natural language. The AI understands complex
                instructions like "place the character in a snowy mountain" or "enhance the facial features". It
                processes your text prompt and generates perfectly edited images.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-3">
              <AccordionTrigger className="text-left">What makes it better than competitors?</AccordionTrigger>
              <AccordionContent className="text-muted-foreground">
                This model excels in character consistency, scene blending, and one-shot editing. Users report it
                significantly outperforms competitors in preserving facial features and seamlessly integrating edits
                with backgrounds. It also supports multi-image context, making it ideal for creating consistent AI
                content.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-4">
              <AccordionTrigger className="text-left">Can I use it for commercial projects?</AccordionTrigger>
              <AccordionContent className="text-muted-foreground">
                Yes! It's perfect for creating AI UGC content, social media campaigns, and marketing materials. Many
                users leverage it for creating consistent AI influencers and product photography. The high-quality
                outputs are suitable for professional use.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-5">
              <AccordionTrigger className="text-left">What types of edits can it handle?</AccordionTrigger>
              <AccordionContent className="text-muted-foreground">
                The editor handles complex edits including face enhancement, background changes, object placement, style
                transfers, and character modifications. It excels at understanding contextual instructions while
                maintaining photorealistic quality.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-6">
              <AccordionTrigger className="text-left">How do I get started?</AccordionTrigger>
              <AccordionContent className="text-muted-foreground">
                Simply upload your image using the editor above, enter a text prompt describing your desired edits, and
                watch as Nano Banana AI transforms your photo with incredible accuracy and consistency. No technical
                knowledge required!
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-20 text-center relative">
        <div className="absolute top-10 right-20 text-6xl opacity-10 pointer-events-none">🍌</div>
        <div className="absolute bottom-10 left-20 text-5xl opacity-10 pointer-events-none rotate-45">🍌</div>
        <h3 className="text-3xl md:text-5xl font-bold text-foreground mb-4 text-balance">
          Ready to Transform Your Images?
        </h3>
        <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto text-pretty">
          Experience the power of Nano Banana yourself. Start creating stunning AI-edited images today.
        </p>
        <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90">
          Try Nano Banana Now
        </Button>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-muted/30">
        <div className="container mx-auto px-4 py-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="text-xl">🍌</div>
              <span className="font-semibold text-foreground">Nano Banana</span>
            </div>
            <p className="text-sm text-muted-foreground">© 2026 Nano Banana. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
